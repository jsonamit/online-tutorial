<?php $__env->startSection('content'); ?>

        <div class="row" style="margin-top: 7%">
            <div class="col-md-4 col-md-offset-3">
                <form  action="<?php echo e(route('topic.insert')); ?>" method="get">
                
                    <div class="form-group">
                        <label for="name">Languages</label>
                        <select class="form-control" name="lang_id" id="sel1">
                            <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($l->id); ?>"><?php echo e($l->langname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Topics</label>
                        <input type="text" placeholder="Topic" class="form-control" name="topic" id="name" required>

                    </div>

                    <button type="submit" style="margin-top: 30px;"  class="btn btn-block btn-success">Submit</button>
                    <a href="<?php echo e(route('topics.bind')); ?>"><button type="button" style="margin-top: 30px;"  class="btn btn-block btn-primary">Display</button></a>
                </form>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>