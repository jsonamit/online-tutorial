<?php $__env->startSection('content'); ?>

<div class="row">
    <h2 style="margin-left: 27%;">Update language</h2>
</div>
    <div class="row" style="margin-top: 7%;">

        <div class="col-md-4 col-md-offset-3">
            <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <form  action="<?php echo e(route('lang.update.submit',['id'=>$langs->id])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="name">Language name</label>
                    <input type="text" placeholder="Language name" class="form-control" value="<?php echo e($langs->langname); ?>" name="langname" id="name">
                </div>

                <button type="submit" style="margin-top: 30px;"  class="btn btn-block btn-success">Submit</button>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>