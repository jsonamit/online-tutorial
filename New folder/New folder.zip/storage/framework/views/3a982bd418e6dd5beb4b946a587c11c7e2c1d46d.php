<?php $__env->startSection('content'); ?>

        <div class="row" >
            <table class="table table-striped">
                <tr>
                    <th>Lang Name</th>
                    <th>Updated_at</th>
                    <th>Created_at</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(strtoupper($langs->langname)); ?></td>
                    <td><?php echo e(date('Y-m-d',strtotime($langs->updated_at))); ?></td>
                    <td><?php echo e(date('Y-m-d',strtotime($langs->created_at))); ?></td>
                    <td>
                        <a href="<?php echo e(route('lang.delete',['id'=>$langs->id])); ?>"><button type="button" class="btn btn-primary">Delete</button></a>
                        <a href="<?php echo e(route('lang.update',['id'=>$langs->id])); ?>"><button type="button" class="btn btn-primary">Update</button></a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>