<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="col-md-3" style="margin-left: -30px;">

            <div class="nav-side-menu">
                <div class="brand">Brand Logo</div>
                <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
                <div class="menu-list">
                    <ul id="menu-content" class="menu-content collapse out">
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('sidebar.topic',["id"=>$lang_id,"topicid"=>$lang->id])); ?>">
                                    <i class="fa fa-dashboard fa-lg"></i> <?php echo e($lang->topic); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <?php if(!empty($subtopic)): ?>
                <div class="row">

                    <h2><?php echo e($subtopic->title); ?></h2>

                    <p><?php echo html_entity_decode($subtopic->description); ?></p>
                    <hr/>

                </div>
                <div class="row">
                    <h2>What is <?php echo e($subtopic->title); ?>?</h2>
                    <ul>
                        <?php if(!empty($subtopic->quest_headone)): ?>
                            <li><?php echo e($subtopic->quest_headone); ?></li>
                        <?php endif; ?>
                            <?php if(!empty($subtopic->quest_headtwo)): ?>
                            <li><?php echo e($subtopic->quest_headtwo); ?>.</li>
                            <?php endif; ?>
                            <?php if(!empty($subtopic->quest_headthree)): ?>
                            <li><?php echo e($subtopic->quest_headthree); ?>.</li>
                          <?php endif; ?>
                            <?php if(!empty($subtopic->quest_headfour)): ?>
                                <li><?php echo e($subtopic->quest_headfour); ?>.</li>
                            <?php endif; ?>

                    </ul>
                </div>

                <div class="row">
                    <h2><?php echo e($subtopic->title); ?> Example</h2>
                    <?php if(!empty($subtopic->output)): ?>
                        <p>Let's see a simple <strong><?php echo e($subtopic->output); ?></strong> in <?php echo e($subtopic->title); ?> programming.
                        <?php endif; ?>

                    </p>
                </div>

                <div class="row">
                    <?php if(!empty($subtopic->example)): ?>
                        <pre style="box-shadow: 0 0 11px;">
 <?php echo html_entity_decode($subtopic->example); ?>


                          </pre>
                        <?php endif; ?>

                </div>

                <div class="row">
                    <p>Output:</p>
                    <?php if(!empty($subtopic->output)): ?>
                        <div class="code1">
                            <pre><?php echo e($subtopic->output); ?></pre>
                        </div>
                        <?php endif; ?>

                    <br/>
                    <br/>
                    <hr/>
                    <h2>Features of <?php echo e($subtopic->title); ?> Programming</h2>
                    <ol type="1">
                        <?php if(!empty($subtopic->features_headone)): ?>
                            <li><strong><?php echo e($subtopic->features_headone); ?></strong><br/>
                                <pre>
<?php echo e($subtopic->features_headone); ?>

                            </pre>
                            </li>
                        <?php endif; ?>
                            <br/>
                            <?php if(!empty($subtopic->features_headtwo)): ?>
                            <li><strong><?php echo e($subtopic->features_headtwo); ?></strong><br/>
                                <pre>
<?php echo e($subtopic->features_headtwo); ?>

</pre></li>
                            <?php endif; ?>
                                <br/>
                            <?php if(!empty($subtopic->features_headthree)): ?>
                            <li><strong><?php echo e($subtopic->features_headthree); ?></strong><br/>
                                <pre>
<?php echo e($subtopic->features_headthree); ?>

                                </pre></li>
                            <?php endif; ?>

                    </ol>
                </div>

            <?php else: ?>

                <div class="row">

                    <h2><?php echo e($hellopage->title); ?> Tutorial</h2>
                    <p><?php echo html_entity_decode($hellopage->description); ?></p>
                    <hr/>

                </div>
                <div class="row">
                    <h2>What is <?php echo e($hellopage->title); ?>?</h2>
                    <ul>
                        <?php if(!empty($hellopage->quest_headone)): ?>
                            <li><?php echo e($hellopage->quest_headone); ?></li>
                        <?php endif; ?>
                        <?php if(!empty($hellopage->quest_headtwo)): ?>
                            <li><?php echo e($hellopage->quest_headtwo); ?>.</li>
                            <?php endif; ?>
                        <?php if(!empty($hellopage->quest_headthree)): ?>
                            <li><?php echo e($hellopage->quest_headthree); ?>.</li>
                        <?php endif; ?>
                            <?php if(!empty($hellopage->quest_headfour)): ?>
                                <li><?php echo e($hellopage->quest_headfour); ?>.</li>
                            <?php endif; ?>

                    </ul>
                </div>
                <div class="row">
                    <h2><?php echo e($hellopage->title); ?> Example</h2>
                    <?php if(!empty($hellopage->output)): ?>
                        <p>Let's see a simple <strong><?php echo e($hellopage->output); ?></strong> in <?php echo e($hellopage->title); ?> programming.
                            <?php endif; ?>

                        </p>
                </div>

                <div class="row">
                    <?php if(!empty($hellopage->example)): ?>
                        <pre style="box-shadow: 0 0 11px;">
 <?php echo html_entity_decode($hellopage->example); ?>


                          </pre>
                    <?php endif; ?>

                </div>
                <div class="row">
                    <p>Output:</p>
                    <?php if(!empty($hellopage->output)): ?>
                        <div class="code1">
                            <pre><?php echo e($hellopage->output); ?></pre>
                        </div>
                    <?php endif; ?>

                    <br/>
                    <br/>
                    <hr/>
                    <h2>Features of <?php echo e($hellopage->title); ?> Programming</h2>
                    <ol type="1">
                        <?php if(!empty($hellopage->features_headone)): ?>
                            <li><strong><?php echo e($hellopage->features_headone); ?></strong><br/>
                                <pre>
<?php echo e($hellopage->features_headone); ?>

                            </pre>
                            </li>
                        <?php endif; ?>
                            <br/>
                        <?php if(!empty($hellopage->features_headtwo)): ?>
                            <li><strong><?php echo e($hellopage->features_headtwo); ?></strong><br/>
                                <pre>
<?php echo e($hellopage->features_headtwo); ?>

</pre>
                                <?php endif; ?>
                                <br/>
                        <?php if(!empty($hellopage->features_headthree)): ?>
                            <li><strong><?php echo e($hellopage->features_headthree); ?></strong><br/>
                                <pre>
<?php echo e($hellopage->features_headthree); ?>

</pre>
                        <?php endif; ?>

                    </ol>
                </div>
            <?php endif; ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>