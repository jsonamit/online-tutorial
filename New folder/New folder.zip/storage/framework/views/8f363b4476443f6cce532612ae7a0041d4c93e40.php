<?php $__env->startSection('content'); ?>

    <div class="row" >
        <table class="table table-striped">
            <tr>
                <th>Lang Name</th>
                <th>Qustion_HeadOne</th>
                <th>Output</th>
                <th>Features</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $subtopic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo html_entity_decode($topics->title); ?></td>
                    <td><?php echo e($topics->quest_headone); ?></td>
                    <td><?php echo e($topics->output); ?></td>
                    <td><?php echo e($topics->features_headone); ?></td>
                    <td>
                        <a href="<?php echo e(route('subtopic.delete',["id"=>$topics->id])); ?>"><button type="button" class="btn btn-primary">Delete</button></a>
                        <a href="<?php echo e(route('update.subtopic',["id"=>$topics->id])); ?>"><button type="button" class="btn btn-primary">Update</button></a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>