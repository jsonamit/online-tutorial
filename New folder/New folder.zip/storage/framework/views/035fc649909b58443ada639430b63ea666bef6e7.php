<?php $__env->startSection('content'); ?>


<div class="row" style="margin-top: 7%;">
        <div class="col-md-4 col-md-offset-3">
            <form  action="<?php echo e(route('lang.insert')); ?>" method="get">
                <div class="form-group">
                    <label for="name">Language name</label>
                    <input type="text" placeholder="Language name" class="form-control" name="langname" id="name" required>
                </div>

                <button type="submit" style="margin-top: 30px;"  class="btn btn-block btn-success">Submit</button>
                <a href="<?php echo e(route('lang.bind')); ?>"><button type="button" style="margin-top: 30px;"  class="btn btn-block btn-primary">Display</button></a>
            </form>
        </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>