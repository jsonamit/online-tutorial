<?php $__env->startSection('content'); ?>
    <div class="container">


        <div class="row">
            <h1 class="head" style="padding-bottom: 32px;text-align: center;">A Program In</h1>
        </div>
        <div class="main">


            <ul class="box-back">
                <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="portion">
                        <h2 class="h2"><?php echo e($langs->langname); ?></h2>
                        <a href="<?php echo e(route('sidebar.topic',['id'=>$langs->id])); ?>" class="button">Learn <?php echo e($langs->langname); ?></a>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>