<?php $__env->startSection('content'); ?>

    <div class="row" >
        <table class="table table-striped">
            <tr>
                <th>Lang Name</th>
                <th>Updated_at</th>
                <th>Created_at</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $topic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(ucfirst($topics->topic)); ?></td>
                    <td><?php echo e(date('Y-m-d',strtotime($topics->updated_at))); ?></td>
                    <td><?php echo e(date('Y-m-d',strtotime($topics->created_at))); ?></td>
                    <td>
                        <a href="<?php echo e(route('topics.delete',['id'=>$topics->id])); ?>"><button type="button" class="btn btn-primary">Delete</button></a>
                        <a href=""><button type="button" class="btn btn-primary">Update</button></a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>